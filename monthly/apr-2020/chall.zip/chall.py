import secrets, sympy, binascii, math

m = int(binascii.hexlify(b"REDACTED"), 16)

p = sympy.nextprime(secrets.randbits(512))
q = sympy.nextprime(secrets.randbits(512))
e = 0x10001
assert math.gcd(e, (p-1)*(q-1)) == 1

n = p*q
print("n =", n)
print("x =", p^q)

c = pow(m, e, n)

print("Ciphertext:", c)
