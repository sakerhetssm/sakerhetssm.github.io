#include <stdio.h>
#include <string.h>
#include "flag.h"

#define MIN(A,B) (A < B ? A : B)

int confirmpass(char *pass) {
	unsigned int len = strlen(pass);
//	printf("%i\n", len);

	if (len > 0) {
		for (unsigned int i = 0; i < MIN(len + 1, sizeof(encpass)/2); i++) {
//printf("%i\n", i);
			char c = (encpass[2 * i] << 4) | (encpass[2 * i + 1] & 0x0f);
			if (c != pass[i]) {
				return 0;
			}
		}
		return 1;
	}

	return 0;
}

int main(int argc, char **argv) {
	char pass[100];

	printf("Enter password: ");
	scanf("%s", pass);

	if (!confirmpass(pass)) {
		printf("incorrect password\n");
		return 1;
	}

	printf("Welcome!\n");
	fflush(stdout);
	return 0;
}
